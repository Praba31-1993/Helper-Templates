import React from 'react';

function Analytics(props) {
    return (
        <div>
            
        </div>
    );
}

export default Analytics;