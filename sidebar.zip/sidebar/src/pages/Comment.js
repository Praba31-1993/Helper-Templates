import React from 'react';

function Comment(props) {
    return (
        <div>
            
            <h1>Comment</h1>
        </div>
    );
}

export default Comment;